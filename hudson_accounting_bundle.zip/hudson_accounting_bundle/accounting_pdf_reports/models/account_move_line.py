import ast
from odoo import api, models


class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    @api.model
    def _query_get(self, domain=None):
        self.check_access('read')

        context = dict(self.env.context or {})
        domain = domain or []
        if not isinstance(domain, (list, tuple)):
            domain = ast.literal_eval(domain)

        date_field = 'date'
        if context.get('aged_balance'):
            date_field = 'date_maturity'
        if context.get('date_to'):
            domain += [(date_field, '<=', context['date_to'])]
        if context.get('date_from'):
            if not context.get('strict_range'):
                domain += ['|', (date_field, '>=', context['date_from']),
                           ('account_id.include_initial_balance', '=', True)]
            elif context.get('initial_bal'):
                domain += [(date_field, '<', context['date_from'])]
            else:
                domain += [(date_field, '>=', context['date_from'])]

        if context.get('journal_ids'):
            domain += [('journal_id', 'in', context['journal_ids'])]

        state = context.get('state')
        if state and state.lower() != 'all':
            domain += [('parent_state', '=', state)]
        else:
            # "All Entries" are the draft and posted ones: cancelled entries never count
            domain += [('parent_state', '!=', 'cancel')]

        if context.get('company_id'):
            domain += [('company_id', '=', context['company_id'])]
        elif context.get('allowed_company_ids'):
            domain += [('company_id', 'in', self.env.companies.ids)]
        else:
            domain += [('company_id', '=', self.env.company.id)]

        if context.get('reconcile_date'):
            domain += ['|', ('reconciled', '=', False), '|',
                       ('matched_debit_ids.max_date', '>', context['reconcile_date']),
                       ('matched_credit_ids.max_date', '>', context['reconcile_date'])]

        if context.get('account_tag_ids'):
            domain += [('account_id.tag_ids', 'in', context['account_tag_ids'].ids)]

        if context.get('account_ids'):
            domain += [('account_id', 'in', context['account_ids'].ids)]

        if context.get('analytic_account_ids'):
            val = context['analytic_account_ids']
            analytic_ids = val.ids if hasattr(val, 'ids') else (list(val) if isinstance(val, (list, tuple, set)) else [val])
            domain += [('analytic_distribution', 'in', analytic_ids)]

        if context.get('partner_ids'):
            domain += [('partner_id', 'in', context['partner_ids'].ids)]

        if context.get('partner_categories'):
            domain += [('partner_id.category_id', 'in', context['partner_categories'].ids)]

        where_clause = ""
        where_clause_params = []
        tables = ''
        if domain:
            domain.append(('display_type', 'not in', ('line_section', 'line_note')))
            domain.append(('parent_state', '!=', 'cancel'))

            query = self._search(domain)
            tables, from_params, _to_flush = query.from_clause._sql_tuple
            where_clause, where_params, _to_flush = query.where_clause._sql_tuple
            where_clause_params = list(from_params) + list(where_params)
        return tables, where_clause, where_clause_params

    def format_analytic_distribution(self, distribution):
        """ Render an analytic distribution as "Account A, Account B: 40.0%" lines.

        The keys of the distribution hold one id per analytic plan, comma
        separated, so a single entry may name several accounts.
        """
        self.ensure_one()
        if not distribution:
            return []
        result = []
        for key, percentage in distribution.items():
            accounts = self.env["account.analytic.account"].browse(
                int(account_id) for account_id in key.split(",")
            ).exists()
            if not accounts:
                continue
            names = [
                "%s - %s" % (account.name, account.partner_id.name) if account.partner_id else account.name
                for account in accounts
            ]
            result.append("%s: %s%%" % (", ".join(names), percentage))
        return result
