/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import * as owl from "@odoo/owl";
import { onWillStart, onWillUpdateProps, onMounted, onWillUnmount } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { user } from "@web/core/user";
import { FileKanbanRenderer } from "@dms/js/views/file_kanban_renderer.esm";
import { FileKanbanController } from "@dms/js/views/file_kanban_controller.esm";
import { SearchPanel } from "@web/search/search_panel/search_panel";

const reactiveState = owl.proxy || owl.useState || ((obj) => obj);

patch(FileKanbanRenderer.prototype, {
    setup() {
        super.setup(...arguments);
        this.orm = useService("orm");
        this.action = useService("action");
        this.dmsDirectoriesState = reactiveState({ data: [], currentDir: false });

        // Track which folder card dropdown is open (exclusive — only one at a time)
        this.folderDropdown = reactiveState({ openId: null });
        this.isDmsManagerOrAdmin = false;

        onWillStart(async () => {
            this.isDmsManagerOrAdmin = (
                user.isAdmin ||
                await user.hasGroup("dms.group_dms_manager") ||
                await user.hasGroup("dms_enterprise_features.group_dms_administrator")
            );
            await this.fetchDirectories(this.props);
        });
        
        onWillUpdateProps(async (nextProps) => {
            await this.fetchDirectories(nextProps);
        });

        // Close dropdown when clicking anywhere outside
        this._dmsOutsideClickHandler = (ev) => {
            if (this.folderDropdown.openId && !ev.target.closest(".o_dms_folder_dropdown_wrap")) {
                this.folderDropdown.openId = null;
            }
        };

        onMounted(() => {
            window.addEventListener("pointerdown", this._dmsOutsideClickHandler, true);
            window.addEventListener("click", this._dmsOutsideClickHandler, true);
        });

        onWillUnmount(() => {
            window.removeEventListener("pointerdown", this._dmsOutsideClickHandler, true);
            window.removeEventListener("click", this._dmsOutsideClickHandler, true);
        });
    },

    /**
     * Toggle the folder dropdown — exclusive: closes any other open one first.
     * Uses capture phase so it fires before stopPropagation in child handlers.
     */
    toggleFolderDropdown(ev, dirId) {
        ev.stopPropagation(); // prevent folder card navigation click
        this.folderDropdown.openId = (this.folderDropdown.openId === dirId) ? null : dirId;
    },

    highlight(ev) {
        if (!this.isDmsManagerOrAdmin) {
            return;
        }
        super.highlight(...arguments);
    },

    onDrop(ev) {
        if (!this.isDmsManagerOrAdmin) {
            return;
        }
        super.onDrop(...arguments);
    },

    async fetchDirectories(props) {
        // Only run for dms.file kanban
        if (this.env.searchModel?.resModel !== "dms.file") {
            return;
        }

        // Get global domain to find current directory filter
        const domain = (typeof this.env.searchModel.getGlobalDomain === 'function' ? this.env.searchModel.getGlobalDomain() : this.env.searchModel.domain) || [];
        let directoryId = false;
        let isTrashAction = false;

        const category = this.env.searchModel?.getSections?.()?.find(s => s.fieldName === 'directory_id');
        if (category && category.activeValueId) {
            directoryId = category.activeValueId;
        }

        for (const d of domain) {
            if (Array.isArray(d)) {
                if (d[0] === 'directory_id' && (d[1] === '=' || d[1] === 'child_of')) {
                    directoryId = d[2];
                }
                if (d[0] === 'is_trashed' && d[2] === true) {
                    isTrashAction = true;
                }
            }
        }
        
        this.dmsDirectoriesState.isTrash = isTrashAction;

        let dirDomain;
        if (isTrashAction) {
            dirDomain = [['is_trashed', '=', true]];
            if (directoryId) {
                dirDomain.push(['parent_id', '=', directoryId]);
                const currentDir = await this.orm.read("dms.directory", [directoryId], ["parent_id", "name", "parent_is_trashed"]);
                if (currentDir && currentDir.length > 0) {
                    this.dmsDirectoriesState.currentDir = currentDir[0];
                }
            } else {
                dirDomain.push('|', ['parent_id', '=', false], ['parent_is_trashed', '=', false]);
                this.dmsDirectoriesState.currentDir = false;
            }
        } else {
            dirDomain = [['is_trashed', '=', false]];
            if (directoryId) {
                dirDomain.push(['parent_id', '=', directoryId]);
                const currentDir = await this.orm.read("dms.directory", [directoryId], ["parent_id", "name"]);
                if (currentDir && currentDir.length > 0) {
                    this.dmsDirectoriesState.currentDir = currentDir[0];
                }
            } else {
                dirDomain.push(['is_root_directory', '=', true]);
                this.dmsDirectoriesState.currentDir = false;
            }
        }

        this.dmsDirectoriesState.data = await this.orm.searchRead(
            "dms.directory",
            dirDomain,
            ["name", "color", "count_files", "count_directories", "icon_url", "permission_download", "permission_write", "permission_edit", "permission_unlink", "permission_move", "is_trashed"]
        );

    },

    openDirectory(dirId) {
        if (this.folderDropdown.openId) {
            this.folderDropdown.openId = null;
            return;
        }
        if (this.env.searchModel) {
            const category = this.env.searchModel.getSections().find(s => s.fieldName === 'directory_id');
            if (category) {
                this.env.searchModel.toggleCategoryValue(category.id, dirId || false);
            }
        }
    },

    async setColor(dirId, colorIdx) {
        await this.orm.write("dms.directory", [dirId], { color: colorIdx });
        await this.fetchDirectories(this.props);
    },

    navigateUp() {
        if (this.dmsDirectoriesState.currentDir) {
            const parentId = this.dmsDirectoriesState.currentDir.parent_id ? this.dmsDirectoriesState.currentDir.parent_id[0] : false;
            this.openDirectory(parentId);
        }
    },

    moveDirectory(dirId) {
        this.folderDropdown.openId = null;
        this.action.doAction({
            name: "Move Folder",
            type: "ir.actions.act_window",
            res_model: "dms.move.wizard",
            views: [[false, "form"]],
            target: "new",
            context: {
                active_model: "dms.directory",
                active_ids: [dirId],
            },
        }, {
            onClose: () => {
                this.fetchDirectories(this.props);
            }
        });
    },

    editDirectory(dirId) {
        this.folderDropdown.openId = null;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "dms.directory",
            res_id: dirId,
            views: [[false, "form"]],
            target: "new",
        }, {
            onClose: () => {
                this.fetchDirectories(this.props);
            }
        });
    },

    async trashDirectory(dirId) {
        this.folderDropdown.openId = null;
        await this.orm.call("dms.directory", "action_send_to_trash", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async restoreDirectory(dirId) {
        this.folderDropdown.openId = null;
        await this.orm.call("dms.directory", "action_restore", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async deleteDirectoryPermanently(dirId) {
        this.folderDropdown.openId = null;
        await this.orm.call("dms.directory", "unlink", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async downloadDirectory(dirId) {
        this.folderDropdown.openId = null;
        const action = await this.orm.call("dms.directory", "action_download_directory_zip", [[dirId]]);
        if (action) {
            this.action.doAction(action);
        }
    }
});

patch(FileKanbanController.prototype, {
    setup() {
        super.setup(...arguments);
        this.isDmsManagerOrAdmin = false;
        onWillStart(async () => {
            this.isDmsManagerOrAdmin = (
                user.isAdmin ||
                await user.hasGroup("dms.group_dms_manager") ||
                await user.hasGroup("dms_enterprise_features.group_dms_administrator")
            );
        });
    },

    get canCreate() {
        return Boolean(super.canCreate && this.isDmsManagerOrAdmin);
    },

    uploadDocument() {
        if (!this.isDmsManagerOrAdmin) {
            return;
        }
        super.uploadDocument(...arguments);
    },

    onShare() {
        const selectedIds = this.model.root.selection.map((r) => r.resId);
        if (!selectedIds.length) return;
        return this.actionService.doAction({
            name: "Share",
            type: "ir.actions.act_window",
            res_model: "dms.file.share.wizard",
            views: [[false, "form"]],
            target: "new",
            context: {
                default_file_id: selectedIds[0],
                active_id: selectedIds[0],
                active_ids: selectedIds,
            },
        });
    },

    createDirectory() {
        if (!this.isDmsManagerOrAdmin) {
            return;
        }
        const domain = (typeof this.env.searchModel?.getGlobalDomain === 'function' ? this.env.searchModel.getGlobalDomain() : this.env.searchModel?.domain) || [];
        let directoryId = false;

        for (const d of domain) {
            if (Array.isArray(d)) {
                if (d[0] === 'directory_id' && (d[1] === '=' || d[1] === 'child_of')) {
                    directoryId = d[2];
                }
            }
        }

        const context = {};
        if (directoryId) {
            context.default_parent_id = directoryId;
        }

        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: "dms.directory",
            views: [[false, "form"]],
            target: "new",
            context: context,
        }, {
            onClose: () => {
                if (this.model && this.model.root) {
                    this.model.root.load();
                }
            }
        });
    }
});

patch(SearchPanel.prototype, {
    moveSidebarDirectory(dirId) {
        const actionService = this.action || this.env.services.action;
        actionService.doAction({
            name: "Move Folder",
            type: "ir.actions.act_window",
            res_model: "dms.move.wizard",
            views: [[false, "form"]],
            target: "new",
            context: {
                active_model: "dms.directory",
                active_ids: [dirId],
            },
        }, {
            onClose: () => {
                const controller = actionService.currentController;
                if (controller) {
                    actionService.restore(controller.jsId);
                }
            }
        });
    },

    async editSidebarDirectory(dirId) {
        const actionService = this.action || this.env.services.action;
        actionService.doAction({
            type: "ir.actions.act_window",
            res_model: "dms.directory",
            res_id: dirId,
            views: [[false, "form"]],
            target: "new",
        }, {
            onClose: () => {
                const controller = actionService.currentController;
                if (controller) {
                    actionService.restore(controller.jsId);
                }
            }
        });
    },

    async trashSidebarDirectory(dirId) {
        const actionService = this.action || this.env.services.action;
        const ormService = this.orm || this.env.services.orm;
        await ormService.call("dms.directory", "action_send_to_trash", [[dirId]]);
        const controller = actionService.currentController;
        if (controller) {
            actionService.restore(controller.jsId);
        }
    },

    async downloadSidebarDirectory(dirId) {
        const actionService = this.action || this.env.services.action;
        const ormService = this.orm || this.env.services.orm;
        const action = await ormService.call("dms.directory", "action_download_directory_zip", [[dirId]]);
        if (action) {
            actionService.doAction(action);
        }
    }
});
