/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { onWillStart, onWillUpdateProps, proxy } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { user } from "@web/core/user";
import { FileListRenderer } from "@dms/js/views/file_list_renderer.esm";
import { FileListController } from "@dms/js/views/file_list_controller.esm";
import { FileListView } from "@dms/js/views/file_list_view.esm";
import { ListController } from "@web/views/list/list_controller";

// Bind Controller on FileListView
FileListView.Controller = FileListController;

patch(FileListRenderer.prototype, {
    setup() {
        super.setup(...arguments);
        this.orm = useService("orm");
        this.action = useService("action");
        this.dmsDirectoriesState = proxy({ data: [], currentDir: false });
        this.isDmsManagerOrAdmin = false;
        
        onWillStart(async () => {
            this.isDmsManagerOrAdmin = (
                user.isAdmin ||
                await user.hasGroup("dms.group_dms_manager") ||
                await user.hasGroup("dms_enterprise_features.group_dms_administrator")
            );
            await this.fetchDirectories(this.props);
        });
        
        onWillUpdateProps(async (nextProps) => {
            await this.fetchDirectories(nextProps);
        });
    },

    highlight(ev) {
        if (!this.isDmsManagerOrAdmin) return;
        super.highlight(...arguments);
    },

    onDrop(ev) {
        if (!this.isDmsManagerOrAdmin) return;
        super.onDrop(...arguments);
    },

    async fetchDirectories(props) {
        if (this.env.searchModel?.resModel !== "dms.file") {
            return;
        }

        const domain = (typeof this.env.searchModel.getGlobalDomain === 'function' ? this.env.searchModel.getGlobalDomain() : this.env.searchModel.domain) || [];
        let directoryId = false;
        let isTrashAction = false;

        const category = this.env.searchModel?.getSections?.()?.find(s => s.fieldName === 'directory_id');
        if (category && category.activeValueId) {
            directoryId = category.activeValueId;
        }

        for (const d of domain) {
            if (Array.isArray(d)) {
                if (d[0] === 'directory_id' && (d[1] === '=' || d[1] === 'child_of')) {
                    directoryId = d[2];
                }
                if (d[0] === 'is_trashed' && d[2] === true) {
                    isTrashAction = true;
                }
            }
        }
        
        this.dmsDirectoriesState.isTrash = isTrashAction;

        let dirDomain;
        if (isTrashAction) {
            dirDomain = [['is_trashed', '=', true]];
            if (directoryId) {
                dirDomain.push(['parent_id', '=', directoryId]);
                const currentDir = await this.orm.read("dms.directory", [directoryId], ["parent_id", "name", "parent_is_trashed"]);
                if (currentDir && currentDir.length > 0) {
                    this.dmsDirectoriesState.currentDir = currentDir[0];
                }
            } else {
                dirDomain.push('|', ['parent_id', '=', false], ['parent_is_trashed', '=', false]);
                this.dmsDirectoriesState.currentDir = false;
            }
        } else {
            dirDomain = [['is_trashed', '=', false]];
            if (directoryId) {
                dirDomain.push(['parent_id', '=', directoryId]);
                const currentDir = await this.orm.read("dms.directory", [directoryId], ["parent_id", "name"]);
                if (currentDir && currentDir.length > 0) {
                    this.dmsDirectoriesState.currentDir = currentDir[0];
                }
            } else {
                dirDomain.push(['is_root_directory', '=', true]);
                this.dmsDirectoriesState.currentDir = false;
            }
        }

        this.dmsDirectoriesState.data = await this.orm.searchRead(
            "dms.directory",
            dirDomain,
            ["name", "display_name", "color", "count_files", "count_directories", "icon_url", "write_date", "permission_download", "permission_write", "permission_edit", "permission_unlink", "permission_move", "is_trashed"]
        );

    },

    openDirectory(dirId) {
        if (this.env.searchModel) {
            const category = this.env.searchModel.getSections().find(s => s.fieldName === 'directory_id');
            if (category) {
                this.env.searchModel.toggleCategoryValue(category.id, dirId || false);
            }
        }
    },

    async setColor(dirId, colorIdx) {
        await this.orm.write("dms.directory", [dirId], { color: colorIdx });
        await this.fetchDirectories(this.props);
    },

    navigateUp() {
        if (this.dmsDirectoriesState.currentDir) {
            const parentId = this.dmsDirectoriesState.currentDir.parent_id ? this.dmsDirectoriesState.currentDir.parent_id[0] : false;
            this.openDirectory(parentId);
        }
    },

    editDirectory(dirId) {
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "dms.directory",
            res_id: dirId,
            views: [[false, "form"]],
            target: "new",
        }, {
            onClose: () => {
                this.fetchDirectories(this.props);
            }
        });
    },

    async trashDirectory(dirId) {
        await this.orm.call("dms.directory", "action_send_to_trash", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async restoreDirectory(dirId) {
        await this.orm.call("dms.directory", "action_restore", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async deleteDirectoryPermanently(dirId) {
        await this.orm.call("dms.directory", "unlink", [[dirId]]);
        await this.fetchDirectories(this.props);
        if (this.props.list) {
            await this.props.list.load();
        }
        if (this.env.searchModel) {
            this.env.searchModel.trigger("update");
        }
    },

    async downloadDirectory(dirId) {
        const action = await this.orm.call("dms.directory", "action_download_directory_zip", [[dirId]]);
        if (action) {
            this.action.doAction(action);
        }
    }
});

patch(FileListController.prototype, {
    setup() {
        super.setup(...arguments);
        this.isDmsManagerOrAdmin = false;
        onWillStart(async () => {
            this.isDmsManagerOrAdmin = (
                user.isAdmin ||
                await user.hasGroup("dms.group_dms_manager") ||
                await user.hasGroup("dms_enterprise_features.group_dms_administrator")
            );
        });
    },

    get canCreate() {
        return Boolean(super.canCreate && this.isDmsManagerOrAdmin);
    },

    uploadDocument() {
        if (!this.isDmsManagerOrAdmin) {
            return;
        }
        super.uploadDocument(...arguments);
    },
});

patch(ListController.prototype, {
    setup() {
        super.setup(...arguments);
        if (this.props.resModel === "dms.file") {
            this.isDmsManagerOrAdmin = false;
            onWillStart(async () => {
                this.isDmsManagerOrAdmin = (
                    user.isAdmin ||
                    await user.hasGroup("dms.group_dms_manager") ||
                    await user.hasGroup("dms_enterprise_features.group_dms_administrator")
                );
            });
        }
    },

    get canCreate() {
        if (this.props.resModel === "dms.file") {
            return Boolean(super.canCreate && this.isDmsManagerOrAdmin);
        }
        return super.canCreate;
    },
});
