from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import timedelta
from dateutil.relativedelta import relativedelta
import uuid

class HudsonDynamicReport(models.AbstractModel):
    _name = "hudson.dynamic.report"
    _description = "Dynamic Report Endpoint"

    @api.model
    def action_open_statement(self, partner_id):
        # Create a transient wizard for the partner ledger
        wiz = self.env['account.report.partner.ledger'].create({
            'result_selection': 'customer_supplier',
        })
        data = wiz.read()[0]
        data['form'] = data.copy()
        data['form']['used_context'] = {}
        data['form']['reconciled'] = False
        data['form']['partner_ids'] = [partner_id]
        
        return {
            'name': 'Customer Statement',
            'type': 'ir.actions.client',
            'tag': 'hudson_dynamic_reports.dynamic_report',
            'params': {
                'model_name': 'account.report.partner.ledger',
                'wizard_id': wiz.id,
                'data': data
            }
        }

    @api.model
    def get_report_data(self, model_name, wizard_id, data):
        error_result = {
            'title': _('Session Expired'),
            'columns': [{'label': 'Message', 'field': 'message'}],
            'lines': [{'id': 'error', 'message': _('Report session expired or parameters missing. Please generate the report again from the menu.')}],
            'currency_id': self.env.company.currency_id.id,
            'company_id': self.env.company.id,
        }
        
        if not model_name:
            return error_result

        form_data = data.get('form', data)
        
        # In case wizard was garbage collected (breadscrumbs), we try to proceed using form_data

        form_data = data.get('form', data)
        
        if wizard_id:
            try:
                wizard = self.env[model_name].browse(wizard_id)
                if wizard.exists():
                    if hasattr(wizard, 'check_report'):
                        full_action = wizard.check_report()
                        if isinstance(full_action, dict) and full_action.get('data'):
                            wiz_form = full_action['data'].get('form', {})
                            for k, v in wiz_form.items():
                                if k not in form_data:
                                    form_data[k] = v
                    else:
                        if not form_data.get('date_from') and hasattr(wizard, 'date_from') and wizard.date_from:
                            form_data['date_from'] = fields.Date.to_string(wizard.date_from)
                        if not form_data.get('date_to') and hasattr(wizard, 'date_to') and wizard.date_to:
                            form_data['date_to'] = fields.Date.to_string(wizard.date_to)
            except Exception:
                pass
        
        # Ensure used_context is built and up-to-date with date_from/date_to!
        if 'used_context' not in form_data:
            form_data['used_context'] = {}
        
        # Overwrite used_context dates with form_data dates to be safe
        if form_data.get('date_from'):
            form_data['used_context']['date_from'] = form_data['date_from']
            form_data['used_context']['strict_range'] = True
        else:
            form_data['used_context']['date_from'] = False
            
        if form_data.get('date_to'):
            form_data['used_context']['date_to'] = form_data['date_to']
        else:
            form_data['used_context']['date_to'] = False

        if form_data.get('target_move'):
            form_data['used_context']['state'] = form_data['target_move']
            
        if form_data.get('partner_ids'):
            form_data['used_context']['partner_ids'] = self.env['res.partner'].browse(form_data['partner_ids'])
            
        if form_data.get('analytic_account_ids') or form_data.get('analytic_plan_ids'):
            analytic_accounts = self.env['account.analytic.account'].browse(form_data.get('analytic_account_ids', []))
            if form_data.get('analytic_plan_ids'):
                plan_accounts = self.env['account.analytic.account'].search([('plan_id', 'in', form_data['analytic_plan_ids'])])
                analytic_accounts |= plan_accounts
            if analytic_accounts:
                form_data['used_context']['analytic_account_ids'] = analytic_accounts

        # Comparison logic
        cmp_periods_info = []
        date_from_str = form_data.get('date_from')
        date_to_str = form_data.get('date_to')
        base_label = 'Balance'
        if date_to_str:
            try:
                # Convert YYYY-MM-DD to DD/MM/YYYY for label
                dparts = date_to_str.split('-')
                if len(dparts) == 3:
                    base_label = f"As of {dparts[2]}/{dparts[1]}/{dparts[0]}"
                else:
                    base_label = _('As of %s') % date_to_str
            except Exception:
                base_label = _('As of %s') % date_to_str

        if form_data.get('comparison') and form_data.get('comparison') != 'no_comparison':
            date_from = fields.Date.from_string(date_from_str) if date_from_str else False
            date_to = fields.Date.from_string(date_to_str) if date_to_str else False
            
            if date_from and date_to:
                if form_data['comparison'] == 'previous_period':
                    periods = int(form_data.get('previous_periods', 1))
                    delta = date_to - date_from + timedelta(days=1)
                    for p in range(1, periods + 1):
                        date_from_cmp = date_from - (delta * p)
                        date_to_cmp = date_from - (delta * (p - 1)) - timedelta(days=1)
                        cmp_date_to_str = fields.Date.to_string(date_to_cmp)
                        dparts = cmp_date_to_str.split('-')
                        label = f"As of {dparts[2]}/{dparts[1]}/{dparts[0]}" if len(dparts) == 3 else f"As of {cmp_date_to_str}"
                        cmp_periods_info.append({
                            'p': p,
                            'date_from': fields.Date.to_string(date_from_cmp),
                            'date_to': cmp_date_to_str,
                            'label': label
                        })
                elif form_data['comparison'] == 'same_last_year':
                    periods = int(form_data.get('previous_periods', 1))
                    for p in range(1, periods + 1):
                        date_from_cmp = date_from - relativedelta(years=p)
                        date_to_cmp = date_to - relativedelta(years=p)
                        cmp_date_to_str = fields.Date.to_string(date_to_cmp)
                        dparts = cmp_date_to_str.split('-')
                        label = f"As of {dparts[2]}/{dparts[1]}/{dparts[0]}" if len(dparts) == 3 else f"As of {cmp_date_to_str}"
                        cmp_periods_info.append({
                            'p': p,
                            'date_from': fields.Date.to_string(date_from_cmp),
                            'date_to': cmp_date_to_str,
                            'label': label
                        })
                elif form_data['comparison'] == 'specific_date':
                    date_to_cmp_str = form_data.get('date_to_cmp')
                    date_from_cmp_str = form_data.get('date_from_cmp') or date_to_cmp_str
                    if date_to_cmp_str:
                        dparts = date_to_cmp_str.split('-')
                        label = f"As of {dparts[2]}/{dparts[1]}/{dparts[0]}" if len(dparts) == 3 else f"As of {date_to_cmp_str}"
                        cmp_periods_info.append({
                            'p': 1,
                            'date_from': date_from_cmp_str,
                            'date_to': date_to_cmp_str,
                            'label': label
                        })

        # Put it back in data just in case
        data['form'] = form_data

        result = {
            'title': 'Report',
            'columns': [],
            'lines': [],
            'currency_id': self.env.company.currency_id.id,
            'company_id': self.env.company.id,
        }

        if model_name == 'accounting.report':
            # Profit and Loss / Balance Sheet
            report_name = form_data.get('account_report_id')
            
            if not form_data.get('account_report_id'):
                raise UserError(_("Report parameters lost or session expired. Please re-generate the report from the menu."))
                
            if isinstance(report_name, list) and len(report_name) > 1:
                result['title'] = report_name[1]
            elif isinstance(report_name, tuple) and len(report_name) > 1:
                result['title'] = report_name[1]
            else:
                result['title'] = _("Financial Report")
                
            debit_credit = form_data.get('debit_credit')
            
            result['columns'] = [{'label': 'Name', 'field': 'name'}]
            if debit_credit:
                result['columns'].append({'label': 'Debit', 'field': 'debit', 'type': 'monetary'})
                result['columns'].append({'label': 'Credit', 'field': 'credit', 'type': 'monetary'})
            result['columns'].append({'label': base_label, 'field': 'balance', 'type': 'monetary'})
            
            report_model = self.env['report.accounting_pdf_reports.report_financial']
            all_lines_map = {}
            ordered_keys = []
            
            if not cmp_periods_info:
                form_data['enable_filter'] = False
                lines = report_model.with_context(active_model=model_name).get_account_lines(form_data)
                for line in lines:
                    key = (line.get('name'), line.get('type'), line.get('level'))
                    if key not in all_lines_map:
                        all_lines_map[key] = line.copy()
                        ordered_keys.append(key)
            else:
                for cmp_info in cmp_periods_info:
                    p = cmp_info['p']
                    result['columns'].append({'label': cmp_info['label'], 'field': f'balance_cmp_{p}', 'type': 'monetary'})
                    
                    form_data['enable_filter'] = True
                    form_data['filter_cmp'] = 'filter_date'
                    form_data['comparison_context'] = dict(form_data['used_context'])
                    form_data['comparison_context']['date_from'] = cmp_info['date_from']
                    form_data['comparison_context']['date_to'] = cmp_info['date_to']
                    
                    lines = report_model.with_context(active_model=model_name).get_account_lines(form_data)
                    for line in lines:
                        key = (line.get('name'), line.get('type'), line.get('level'))
                        if key not in all_lines_map:
                            all_lines_map[key] = line.copy()
                            for i in range(1, len(cmp_periods_info) + 1):
                                all_lines_map[key][f'balance_cmp_{i}'] = 0.0
                            ordered_keys.append(key)
                        all_lines_map[key]['balance'] = line['balance']
                        if debit_credit:
                            all_lines_map[key]['debit'] = line.get('debit', 0.0)
                            all_lines_map[key]['credit'] = line.get('credit', 0.0)
                        all_lines_map[key][f'balance_cmp_{p}'] = line.get('balance_cmp', 0.0)

            seen_ids = {}
            formatted_lines = []
            for key in ordered_keys:
                line = all_lines_map[key]
                base_id = f"{line.get('type')}_{line.get('name')}"
                if base_id in seen_ids:
                    seen_ids[base_id] += 1
                    line_id = f"{base_id}_{seen_ids[base_id]}"
                else:
                    seen_ids[base_id] = 0
                    line_id = base_id

                formatted_line = {
                    'id': line_id,
                    'name': line.get('name', ''),
                    'debit': line.get('debit', 0.0),
                    'credit': line.get('credit', 0.0),
                    'balance': line.get('balance', 0.0),
                    'level': line.get('level', 1),
                    'type': line.get('type', 'report'),
                }
                for cmp_info in cmp_periods_info:
                    p = cmp_info['p']
                    formatted_line[f'balance_cmp_{p}'] = line.get(f'balance_cmp_{p}', 0.0)
                formatted_lines.append(formatted_line)
                
            result['lines'] = formatted_lines

        elif model_name == 'account.tax.report.wizard':
            result['title'] = _("Tax Report")
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Net', 'field': 'net', 'type': 'monetary'},
                {'label': 'Tax', 'field': 'tax', 'type': 'monetary'},
            ]
            report_model = self.env['report.accounting_pdf_reports.report_tax']
            groups = report_model.with_context(active_model=model_name).get_lines(form_data)
            
            formatted_lines = []
            for group_name, group_lines in groups.items():
                if group_lines:
                    group_tax_total = sum(line.get('tax', 0.0) for line in group_lines)
                    formatted_lines.append({
                        'id': f'group_{group_name}',
                        'name': group_name.capitalize(),
                        'level': 1,
                        'type': 'group',
                        'tax': group_tax_total,
                    })
                    for idx, line in enumerate(group_lines):
                        formatted_lines.append({
                            'id': f'tax_{group_name}_{idx}',
                            'name': line.get('name', ''),
                            'net': line.get('net', 0.0),
                            'tax': line.get('tax', 0.0),
                            'level': 2,
                            'type': 'tax',
                        })
            result['lines'] = formatted_lines
        elif model_name == 'account.tax.extended.wizard':
            result['title'] = _("Tax Report")
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Net', 'field': 'net', 'type': 'monetary'},
                {'label': 'Tax', 'field': 'tax', 'type': 'monetary'},
            ]
            wiz = self.env[model_name].browse(wizard_id)
            if not wiz:
                wiz_vals = form_data.copy()
                wiz_vals.pop('used_context', None)
                wiz_vals.pop('id', None)
                wiz = self.env[model_name].create(wiz_vals)
                
            tax_data = wiz._compute_tax_data()
            
            formatted_lines = []
            
            def add_groups(groups_list, section_name):
                if not groups_list:
                    return
                formatted_lines.append({
                    'id': f'section_{section_name}',
                    'name': section_name,
                    'level': 1,
                    'type': 'group',
                    'tax': sum(g['total_tax'] for g in groups_list),
                })
                for group in groups_list:
                    for idx, tax_line in enumerate(group['taxes']):
                        formatted_lines.append({
                            'id': f"tax_{section_name}_{group['group_name']}_{idx}",
                            'name': tax_line['name'],
                            'net': tax_line['base_amount'],
                            'tax': tax_line['tax_amount'],
                            'tax_id': tax_line['tax_id'],
                            'level': 2,
                            'type': 'tax',
                        })
                        
            add_groups(tax_data['sale_groups'], 'Sales')
            add_groups(tax_data['purchase_groups'], 'Purchases')
            result['lines'] = formatted_lines
        elif model_name == 'account.executive.summary.wizard':
            result['title'] = _("Executive Summary")
            result['columns'] = [
                {'label': '', 'field': 'name'},
            ]
            
            wiz = self.env[model_name].browse(wizard_id)
            if not wiz:
                wiz_vals = form_data.copy()
                wiz_vals.pop('used_context', None)
                wiz_vals.pop('id', None)
                wiz = self.env[model_name].create(wiz_vals)
            
            data = wiz._compute_summary_data()
            current = data['current']
            comparison = data['comparison']
            
            result['columns'].append({'label': 'Balance', 'field': 'balance', 'type': 'monetary'})
            if comparison:
                result['columns'].append({'label': 'Comparison', 'field': 'balance_cmp', 'type': 'monetary'})

            formatted_lines = []
            def add_line(name, val, cmp_val=None, type='monetary', level=2):
                formatted_lines.append({
                    'id': str(uuid.uuid4()),
                    'name': name,
                    'level': level,
                    'balance': val,
                    'balance_cmp': cmp_val if cmp_val is not None else 0.0,
                    'type': type,
                })

            def add_header(name):
                formatted_lines.append({
                    'id': str(uuid.uuid4()),
                    'name': name,
                    'level': 1,
                    'type': 'group',
                })

            add_header('Cash')
            add_line('Cash received', current['cash_received'], comparison['cash_received'] if comparison else None)
            add_line('Cash spent', -current['cash_spent'], -comparison['cash_spent'] if comparison else None)
            add_line('Cash surplus', current['cash_surplus'], comparison['cash_surplus'] if comparison else None)
            add_line('Closing bank balance', current['cash'], comparison['cash'] if comparison else None)

            add_header('Profitability')
            add_line('Revenue', current['revenue'], comparison['revenue'] if comparison else None)
            add_line('Cost of Revenue', current['cogs'], comparison['cogs'] if comparison else None)
            add_line('Gross profit', current['gross_profit'], comparison['gross_profit'] if comparison else None)
            add_line('Expenses', current['opex'], comparison['opex'] if comparison else None)
            add_line('Net Profit', current['net_profit'], comparison['net_profit'] if comparison else None)

            add_header('Balance Sheet')
            add_line('Receivables', current['ar'], comparison['ar'] if comparison else None)
            add_line('Payables', -current['ap'], -comparison['ap'] if comparison else None)
            add_line('Net assets', current['net_assets'], comparison['net_assets'] if comparison else None)

            add_header('Performance')
            add_line('Gross profit margin (gross profit / operating income)', current['gross_margin'], comparison['gross_margin'] if comparison else None, type='percent')
            add_line('Net profit margin (net profit / revenue)', current['net_margin'], comparison['net_margin'] if comparison else None, type='percent')
            add_line('Return on investments (net profit / assets)', current['roi'], comparison['roi'] if comparison else None, type='percent')

            add_header('Position')
            add_line('Average debtors days', current['avg_debtors_days'], comparison['avg_debtors_days'] if comparison else None, type='number')
            add_line('Average creditors days', current['avg_creditors_days'], comparison['avg_creditors_days'] if comparison else None, type='number')
            add_line('Short-term cash forecast', current['short_term_cash_forecast'], comparison['short_term_cash_forecast'] if comparison else None)
            add_line('Current assets to liabilities', current['current_ratio'], comparison['current_ratio'] if comparison else None, type='number')

            result['lines'] = formatted_lines

        elif model_name == 'account.report.partner.ledger':
            result['title'] = _("Partner Ledger")
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Journal', 'field': 'journal'},
                {'label': 'Account', 'field': 'account'},
                {'label': 'Invoice Date', 'field': 'date'},
                {'label': 'Due Date', 'field': 'date_maturity'},
                {'label': 'Matching', 'field': 'matching'},
                {'label': 'Debit', 'field': 'debit', 'type': 'monetary'},
                {'label': 'Credit', 'field': 'credit', 'type': 'monetary'},
                {'label': 'Amount Currency', 'field': 'amount_currency', 'type': 'monetary'},
                {'label': 'Balance', 'field': 'balance', 'type': 'monetary'},
            ]
            
            if form_data.get('target_move') != 'posted':
                unposted_count = self.env['account.move'].search_count([('state', '=', 'draft')])
                if unposted_count > 0:
                    result['alert_message'] = _('There are unposted Journal Entries prior or included in this period.')
            
            report_model = self.env['report.accounting_pdf_reports.report_partnerledger']
            report_data = report_model._get_report_values(None, data)
            partners = report_data.get('docs', [])
            
            formatted_lines = []
            total_debit = 0.0
            total_credit = 0.0
            total_balance = 0.0
            
            for p_idx, partner in enumerate(partners):
                p_debit = report_data['sum_partner'](data, partner, 'debit')
                p_credit = report_data['sum_partner'](data, partner, 'credit')
                p_balance = report_data['sum_partner'](data, partner, 'debit - credit')
                
                total_debit += p_debit
                total_credit += p_credit
                total_balance += p_balance
                
                # Level 2: Partner
                formatted_lines.append({
                    'id': f'partner_{partner.id}',
                    'name': partner.name,
                    'debit': p_debit,
                    'credit': p_credit,
                    'balance': p_balance,
                    'level': 2,
                    'type': 'partner',
                    'partner_id': partner.id,
                    'action_buttons': [
                        {'label': 'Partner', 'action': 'open_partner'},
                        {'label': 'Journal Items', 'action': 'open_journal_items'}
                    ]
                })
                
                # Level 3: Lines
                lines = report_data['lines'](data, partner)
                line_ids = [line.get('id') for line in lines if line.get('id')]
                amls = self.env['account.move.line'].browse(line_ids)
                aml_map = {aml.id: aml for aml in amls}
                
                for l_idx, line in enumerate(lines):
                    aml = aml_map.get(line.get('id'))
                    date_maturity = str(aml.date_maturity) if aml and aml.date_maturity else ''
                    matching = aml.full_reconcile_id.name if aml and getattr(aml, 'full_reconcile_id', False) else ''
                    if not matching and aml and getattr(aml, 'matched_debit_ids', False) or getattr(aml, 'matched_credit_ids', False):
                        # Simple matching fallback
                        matching = '*'
                        
                    formatted_lines.append({
                        'id': f'partner_{partner.id}_line_{line["id"]}_{l_idx}',
                        'name': line.get('displayed_name') or line.get('name') or line.get('ref') or '',
                        'journal': line.get('code', ''),
                        'account': line.get('a_name', ''),
                        'date': str(line.get('date', '')),
                        'date_maturity': date_maturity,
                        'matching': matching,
                        'debit': line.get('debit', 0.0),
                        'credit': line.get('credit', 0.0),
                        'amount_currency': line.get('amount_currency', 0.0),
                        'balance': line.get('progress', 0.0),
                        'level': 3,
                        'type': 'account',
                        'partner_id': partner.id,
                        'move_line_id': line.get('id')
                    })
            
            # Prepend Level 1: Partner Ledger Root
            result['lines'] = [{
                'id': 'root',
                'name': 'Partner Ledger',
                'debit': total_debit,
                'credit': total_credit,
                'balance': total_balance,
                'level': 1,
                'type': 'report',
            }] + formatted_lines
            
        elif model_name == 'account.balance.report':
            result['title'] = _("Trial Balance")
            
            # Extract parameters
            date_from = form_data.get('date_from')
            date_to = form_data.get('date_to')
            target_move = form_data.get('target_move', 'posted')
            display_account = form_data.get('display_account', 'all')
            
            period_label = "Current Period"
            if date_from and date_to:
                from datetime import datetime
                d_to = datetime.strptime(date_to, "%Y-%m-%d")
                period_label = d_to.strftime("%b %Y") # e.g., "Aug 2026"
            elif date_from:
                period_label = f"Since {date_from}"
            elif date_to:
                period_label = f"Until {date_to}"
                
            result['column_groups'] = [
                {'label': '', 'colspan': 1},
                {'label': 'Initial Balance', 'colspan': 1},
                {'label': period_label, 'colspan': 2},
                {'label': 'End Balance', 'colspan': 1},
            ]
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Balance', 'field': 'initial_balance', 'type': 'monetary'},
                {'label': 'Debit', 'field': 'debit', 'type': 'monetary'},
                {'label': 'Credit', 'field': 'credit', 'type': 'monetary'},
                {'label': 'Balance', 'field': 'end_balance', 'type': 'monetary'},
            ]
            
            accounts = self.env['account.account'].search([], order="code")
            
            domain_initial = []
            domain_period = []
            
            if target_move == 'posted':
                domain_initial.append(('move_id.state', '=', 'posted'))
                domain_period.append(('move_id.state', '=', 'posted'))
                
            if date_from:
                domain_initial.append(('date', '<', date_from))
                domain_period.append(('date', '>=', date_from))
                
            if date_to:
                domain_period.append(('date', '<=', date_to))
                
            # Compute Initial Balance
            initial_balances = {}
            if date_from:
                query = self.env['account.move.line']._where_calc(domain_initial)
                if hasattr(query, 'from_clause') and hasattr(query.from_clause, 'code'):
                    from_string = query.from_clause.code
                    where_string = query.where_clause.code
                    where_params = query.where_clause.params or []
                else:
                    from_string, from_params = query.from_clause
                    where_string, where_params = query.where_clause
                    where_params = list(from_params) + list(where_params)
                if where_string:
                    self.env.cr.execute(f"SELECT account_id, SUM(debit - credit) as balance FROM {from_string} WHERE {where_string} GROUP BY account_id", where_params)
                    for row in self.env.cr.dictfetchall():
                        initial_balances[row['account_id']] = row['balance']
                        
            # Compute Period Movement
            period_movements = {}
            query = self.env['account.move.line']._where_calc(domain_period)
            if hasattr(query, 'from_clause') and hasattr(query.from_clause, 'code'):
                from_string = query.from_clause.code
                where_string = query.where_clause.code
                where_params = query.where_clause.params or []
            else:
                from_string, from_params = query.from_clause
                where_string, where_params = query.where_clause
                where_params = list(from_params) + list(where_params)
            
            if where_string:
                self.env.cr.execute(f"SELECT account_id, SUM(debit) as debit, SUM(credit) as credit FROM {from_string} WHERE {where_string} GROUP BY account_id", where_params)
                for row in self.env.cr.dictfetchall():
                    period_movements[row['account_id']] = row
            elif not domain_period:
                self.env.cr.execute(f"SELECT account_id, SUM(debit) as debit, SUM(credit) as credit FROM account_move_line GROUP BY account_id")
                for row in self.env.cr.dictfetchall():
                    period_movements[row['account_id']] = row

            formatted_lines = []
            total_initial = 0.0
            total_debit = 0.0
            total_credit = 0.0
            total_end = 0.0
            
            for account in accounts:
                initial_balance = initial_balances.get(account.id, 0.0)
                period_data = period_movements.get(account.id, {'debit': 0.0, 'credit': 0.0})
                debit = period_data['debit'] or 0.0
                credit = period_data['credit'] or 0.0
                end_balance = initial_balance + debit - credit
                
                # Check display criteria
                if display_account == 'not_zero' and round(end_balance, 2) == 0:
                    continue
                if display_account == 'movement' and round(debit, 2) == 0 and round(credit, 2) == 0:
                    continue
                    
                total_initial += initial_balance
                total_debit += debit
                total_credit += credit
                total_end += end_balance
                
                formatted_lines.append({
                    'id': f'account_{account.id}',
                    'name': f"{account.code} {account.name}",
                    'initial_balance': initial_balance,
                    'debit': debit,
                    'credit': credit,
                    'end_balance': end_balance,
                    'level': 2,
                    'type': 'account',
                    'account_id': account.id
                })
                
            unallocated = -total_initial
            if round(unallocated, 2) != 0:
                formatted_lines.append({
                    'id': 'unallocated',
                    'name': _('Result Brought Forward'),
                    'initial_balance': unallocated,
                    'debit': 0.0,
                    'credit': 0.0,
                    'end_balance': unallocated,
                    'level': 2,
                    'type': 'account',
                })
                total_initial += unallocated
                total_end += unallocated
                
            # Add Total Row
            formatted_lines.append({
                'id': 'total',
                'name': _('Total'),
                'initial_balance': total_initial,
                'debit': total_debit,
                'credit': total_credit,
                'end_balance': total_end,
                'level': 1,
                'type': 'total',
            })
            
            if target_move != 'posted':
                unposted_count = self.env['account.move'].search_count([('state', '=', 'draft')])
                if unposted_count > 0:
                    result['alert_message'] = _('There are unposted Journal Entries prior or included in this period.')
                    
            result['lines'] = formatted_lines
            
        elif model_name == 'account.report.general.ledger':
            result['title'] = _("General Ledger")
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Date', 'field': 'date'},
                {'label': 'Partner', 'field': 'partner'},
                {'label': 'Currency', 'field': 'amount_currency', 'type': 'monetary'},
                {'label': 'Debit', 'field': 'debit', 'type': 'monetary'},
                {'label': 'Credit', 'field': 'credit', 'type': 'monetary'},
                {'label': 'Balance', 'field': 'balance', 'type': 'monetary'},
            ]
            
            if form_data.get('target_move') != 'posted':
                unposted_count = self.env['account.move'].search_count([('state', '=', 'draft')])
                if unposted_count > 0:
                    result['alert_message'] = _('There are unposted Journal Entries prior or included in this period.')
            
            report_model = self.env['report.accounting_pdf_reports.report_general_ledger'].with_context(active_model='account.report.general.ledger')
            report_data = report_model._get_report_values(None, data)
            accounts_res = report_data.get('Accounts', [])
            
            formatted_lines = []
            total_debit = 0.0
            total_credit = 0.0
            total_balance = 0.0
            
            for account in accounts_res:
                a_debit = account.get('debit', 0.0)
                a_credit = account.get('credit', 0.0)
                a_balance = account.get('balance', 0.0)
                
                total_debit += a_debit
                total_credit += a_credit
                total_balance += a_balance
                
                formatted_lines.append({
                    'id': f'account_{account["code"]}',
                    'name': f"{account['code']} {account['name']}",
                    'debit': a_debit,
                    'credit': a_credit,
                    'balance': a_balance,
                    'level': 2,
                    'type': 'account',
                    'action_buttons': [{'label': 'Journal Items', 'action': 'open_journal_items', 'class': 'btn-hover-only'}]
                })
                
                for line in account.get('move_lines', []):
                    # initial balance line has lid = 0
                    is_initial = line.get('lid') == 0
                    name_label = line.get('lname')
                    if line.get('lref'):
                        name_label = f"{name_label} - {line.get('lref')}"
                    
                    formatted_lines.append({
                        'id': f'aml_{line.get("lid")}_{account["code"]}',
                        'name': name_label,
                        'date': line.get('ldate') if not is_initial else '',
                        'partner': line.get('partner_name') or '',
                        'amount_currency': line.get('amount_currency') or 0.0,
                        'debit': line.get('debit', 0.0),
                        'credit': line.get('credit', 0.0),
                        'balance': line.get('balance', 0.0),
                        'level': 3,
                        'type': 'move_line',
                        'move_line_id': line.get('lid') if not is_initial else False,
                    })
            
            # Initial Balance Check
            date_from = form_data.get('date_from')
            unallocated = 0.0
            if date_from:
                domain_initial = []
                if form_data.get('target_move') == 'posted':
                    domain_initial.append(('move_id.state', '=', 'posted'))
                domain_initial.append(('date', '<', date_from))
                
                query = self.env['account.move.line']._where_calc(domain_initial)
                if hasattr(query, 'from_clause') and hasattr(query.from_clause, 'code'):
                    from_string = query.from_clause.code
                    where_string = query.where_clause.code
                    where_params = query.where_clause.params or []
                else:
                    from_string, from_params = query.from_clause
                    where_string, where_params = query.where_clause
                    where_params = list(from_params) + list(where_params)
                    
                if where_string:
                    self.env.cr.execute(f"SELECT SUM(debit - credit) as balance FROM {from_string} WHERE {where_string}", where_params)
                    res = self.env.cr.fetchone()
                    if res and res[0]:
                        # The sum of all accounts initial balance
                        unallocated = -res[0]
            
            if round(unallocated, 2) != 0:
                formatted_lines.append({
                    'id': 'unallocated',
                    'name': _('Result Brought Forward'),
                    'debit': 0.0,
                    'credit': 0.0,
                    'balance': unallocated,
                    'level': 2,
                    'type': 'account',
                })
                total_balance += unallocated
            
            formatted_lines.append({
                'id': 'total',
                'name': _('Total General Ledger'),
                'debit': total_debit,
                'credit': total_credit,
                'balance': total_balance,
                'level': 1,
                'type': 'total',
            })
            
            result['lines'] = formatted_lines
        elif model_name == 'account.cash.flow.wizard':
            result['title'] = _("Cash Flow Statement")
            result['columns'] = [
                {'label': 'Name', 'field': 'name'},
                {'label': 'Balance', 'field': 'balance', 'type': 'monetary'},
            ]
            
            wizard = self.env['account.cash.flow.wizard'].browse(wizard_id)
            cf_data = wizard._compute_cash_flow_data()
            
            formatted_lines = []
            
            def add_section(id_str, name, data_dict):
                if round(data_dict.get('total', 0.0), 2) != 0 or data_dict.get('account_lines'):
                    formatted_lines.append({
                        'id': id_str,
                        'name': name,
                        'balance': data_dict.get('total', 0.0),
                        'level': 3,
                        'type': 'group',
                    })
                    for acc in data_dict.get('account_lines', []):
                        formatted_lines.append({
                            'id': f"{id_str}_{acc['id']}",
                            'name': acc['name'],
                            'balance': acc['balance'],
                            'level': 4,
                            'type': 'account',
                            'account_id': acc['id'],
                            'dropdown_actions': [{'label': _('General Ledger'), 'action': 'open_general_ledger'}]
                        })
            
            # Opening Balance
            formatted_lines.append({
                'id': 'opening',
                'name': _('Cash and cash equivalents, beginning of period'),
                'balance': cf_data['opening_cash'],
                'level': 1,
                'type': 'total',
            })
            
            # Net Increase
            formatted_lines.append({
                'id': 'net_increase',
                'name': _('Net increase in cash and cash equivalents'),
                'balance': cf_data['net_increase'],
                'level': 1,
                'type': 'total',
            })
            
            # Operating
            formatted_lines.append({
                'id': 'operating',
                'name': _('Cash flows from operating activities'),
                'balance': cf_data['operating_total'],
                'level': 2,
                'type': 'group',
            })
            add_section('op_adv_in', _('Advance Payments received from customers'), cf_data['op_adv_in'])
            add_section('op_cash_in', _('Cash received from operating activities'), cf_data['op_cash_in'])
            add_section('op_adv_out', _('Advance payments made to suppliers'), cf_data['op_adv_out'])
            add_section('op_cash_out', _('Cash paid for operating activities'), cf_data['op_cash_out'])
            
            # Investing
            formatted_lines.append({
                'id': 'investing',
                'name': _('Cash flows from Investing & extraordinary activities'),
                'balance': cf_data['investing_total'],
                'level': 2,
                'type': 'group',
            })
            add_section('inv_in', _('Cash in'), cf_data['inv_in'])
            add_section('inv_out', _('Cash out'), cf_data['inv_out'])
            
            # Financing
            formatted_lines.append({
                'id': 'financing',
                'name': _('Cash flows from financing activities'),
                'balance': cf_data['financing_total'],
                'level': 2,
                'type': 'group',
            })
            add_section('fin_in', _('Cash in'), cf_data['fin_in'])
            add_section('fin_out', _('Cash out'), cf_data['fin_out'])
            
            # Unclassified
            formatted_lines.append({
                'id': 'unclassified',
                'name': _('Cash flows from unclassified activities'),
                'balance': cf_data['unclassified_total'],
                'level': 2,
                'type': 'group',
            })
            add_section('unclass_in', _('Cash in'), cf_data['unclass_in'])
            add_section('unclass_out', _('Cash out'), cf_data['unclass_out'])
            
            # Closing Balance
            formatted_lines.append({
                'id': 'closing',
                'name': _('Cash and cash equivalents, closing balance'),
                'balance': cf_data['closing_cash'],
                'level': 1,
                'type': 'total',
            })
            
            result['lines'] = formatted_lines
        elif model_name == 'account.aged.report':
            wizard = self.env['account.aged.report'].browse(wizard_id)
            is_payable = wizard.account_type == 'payable'
            result['title'] = _("Aged Payable") if is_payable else _("Aged Receivable")
            
            p = wizard.period_length
            result['columns'] = [
                {'label': '', 'field': 'name'},
                {'label': 'Invoice Date', 'field': 'invoice_date'},
                {'label': 'At Date', 'field': 'not_due', 'type': 'monetary'},
                {'label': f'1 - {p}', 'field': 'p4', 'type': 'monetary'},
                {'label': f'{p+1} - {2*p}', 'field': 'p3', 'type': 'monetary'},
                {'label': f'{2*p+1} - {3*p}', 'field': 'p2', 'type': 'monetary'},
                {'label': f'{3*p+1} - {4*p}', 'field': 'p1', 'type': 'monetary'},
                {'label': 'Older', 'field': 'p0', 'type': 'monetary'},
                {'label': 'Total', 'field': 'total', 'type': 'monetary'},
            ]
            
            cr = self.env.cr
            as_of = wizard.as_of_date
            company = wizard.company_id
            state_filter = "" if getattr(wizard, 'show_draft', False) else "AND am.state = 'posted'"
            
            # Account type and non_trade filtering
            acc_types = ['liability_payable'] if wizard.account_type in ('payable', 'non_trade_payable') else ['asset_receivable']
            sign = -1 if wizard.account_type in ('payable', 'non_trade_payable') else 1
            if wizard.account_type in ('non_trade_receivable', 'non_trade_payable'):
                non_trade_filter = "AND aa.non_trade = TRUE"
            else:
                non_trade_filter = "AND aa.non_trade = FALSE"
                
            # Date basis
            date_basis = getattr(wizard, 'date_basis', 'date_maturity')
            basis_field = 'l.date_maturity' if date_basis == 'date_maturity' else 'l.date'
            date_expr = f"COALESCE({basis_field}, l.date)" if date_basis == 'date_maturity' else basis_field
            
            # Partners filtering
            partner_clause = ''
            partner_args = []
            if wizard.partner_ids:
                if len(wizard.partner_ids) == 1:
                    partner_clause = f"AND l.partner_id = {wizard.partner_ids[0].id}"
                else:
                    partner_clause = "AND l.partner_id IN %s"
                    partner_args.append(tuple(wizard.partner_ids.ids))
                    
            tags_clause = ''
            tags_args = []
            if hasattr(wizard, 'partner_category_ids') and wizard.partner_category_ids:
                tags_clause = """
                    AND EXISTS (
                        SELECT 1 FROM res_partner_res_partner_category_rel rel 
                        WHERE rel.partner_id = l.partner_id AND rel.category_id IN %s
                    )
                """
                tags_args.append(tuple(wizard.partner_category_ids.ids))
            
            periods = {}
            start_date = as_of
            for i in range(4, -1, -1):
                if i == 0:
                    periods[i] = {'start': False, 'stop': start_date}
                else:
                    stop_date = start_date
                    start_date = stop_date - timedelta(days=p)
                    periods[i] = {'start': start_date + timedelta(days=1), 'stop': stop_date}
                start_date = start_date - timedelta(days=1)
                
            cr.execute(
                '''SELECT DISTINCT debit_move_id, credit_move_id
                   FROM account_partial_reconcile
                   WHERE max_date > %s''',
                (as_of,)
            )
            recon_after = []
            for row in cr.fetchall():
                recon_after += [row[0], row[1]]

            recon_clause = '(l.reconciled IS FALSE)'
            recon_args = []
            if recon_after:
                recon_clause = '(l.reconciled IS FALSE OR l.id IN %s)'
                recon_args = [tuple(recon_after)]

            query = f'''
                SELECT 
                    l.id as line_id,
                    l.partner_id, 
                    rp.name AS partner_name,
                    am.id as move_id,
                    am.name as move_name,
                    l.account_id,
                    l.date as invoice_date,
                    l.date_maturity,
                    COALESCE(l.balance * {sign}, 0) AS amt
                FROM account_move_line l
                JOIN account_account aa ON aa.id = l.account_id
                JOIN account_move am ON am.id = l.move_id
                LEFT JOIN res_partner rp ON rp.id = l.partner_id
                WHERE aa.account_type IN %s
                  {non_trade_filter}
                  AND l.date <= %s
                  AND l.company_id = %s
                  {state_filter}
                  AND {recon_clause}
                  {partner_clause}
                  {tags_clause}
                  AND l.display_type NOT IN ('line_section', 'line_note')
                ORDER BY rp.name, l.date
            '''
            cr.execute(query, [tuple(acc_types), as_of, company.id] + recon_args + partner_args + tags_args)
            lines = cr.dictfetchall()
            
            show_account = getattr(wizard, 'show_account', False)
            account_codes = {}
            if show_account:
                account_ids = list(set([line['account_id'] for line in lines if line['account_id']]))
                accounts = self.env['account.account'].browse(account_ids)
                account_codes = {acc.id: acc.code for acc in accounts}
            
            partners_data = {}
            for line in lines:
                amt = line['amt']
                if round(amt, 2) == 0:
                    continue
                    
                pid = line['partner_id'] or 0
                if pid not in partners_data:
                    partners_data[pid] = {
                        'name': line['partner_name'] or _('Unknown'),
                        'partner_id': pid,
                        'not_due': 0, 'p4': 0, 'p3': 0, 'p2': 0, 'p1': 0, 'p0': 0, 'total': 0,
                        'lines': []
                    }
                    
                mat_date = line['date_maturity'] or line['invoice_date']
                if date_basis == 'date':
                    mat_date = line['invoice_date']
                
                acc_code = account_codes.get(line['account_id'])
                line_name = f"{acc_code} - {line['move_name']}" if show_account and acc_code else line['move_name']
                
                line_data = {
                    'id': f"line_{line['line_id']}",
                    'name': line_name,
                    'invoice_date': str(line['invoice_date']) if line['invoice_date'] else '',
                    'not_due': 0, 'p4': 0, 'p3': 0, 'p2': 0, 'p1': 0, 'p0': 0, 'total': amt,
                    'level': 3,
                    'type': 'account',
                    'dropdown_actions': [{'label': _('View Journal Entry'), 'action': 'open_journal_entry'}],
                    'move_id': line['move_id'],
                }
                
                if mat_date >= as_of:
                    line_data['not_due'] = amt
                elif periods[4]['start'] and periods[4]['stop'] and periods[4]['start'] <= mat_date <= periods[4]['stop']:
                    line_data['p4'] = amt
                elif periods[3]['start'] and periods[3]['stop'] and periods[3]['start'] <= mat_date <= periods[3]['stop']:
                    line_data['p3'] = amt
                elif periods[2]['start'] and periods[2]['stop'] and periods[2]['start'] <= mat_date <= periods[2]['stop']:
                    line_data['p2'] = amt
                elif periods[1]['start'] and periods[1]['stop'] and periods[1]['start'] <= mat_date <= periods[1]['stop']:
                    line_data['p1'] = amt
                else:
                    line_data['p0'] = amt
                    
                partners_data[pid]['not_due'] += line_data['not_due']
                partners_data[pid]['p4'] += line_data['p4']
                partners_data[pid]['p3'] += line_data['p3']
                partners_data[pid]['p2'] += line_data['p2']
                partners_data[pid]['p1'] += line_data['p1']
                partners_data[pid]['p0'] += line_data['p0']
                partners_data[pid]['total'] += amt
                partners_data[pid]['lines'].append(line_data)
                
            formatted_lines = []
            g_not_due = g_p4 = g_p3 = g_p2 = g_p1 = g_p0 = g_total = 0.0
            
            hide_lines_at_0 = getattr(wizard, 'hide_lines_at_0', True)
            for pid, pdata in partners_data.items():
                if hide_lines_at_0 and round(pdata['total'], 2) == 0:
                    continue
                g_not_due += pdata['not_due']
                g_p4 += pdata['p4']
                g_p3 += pdata['p3']
                g_p2 += pdata['p2']
                g_p1 += pdata['p1']
                g_p0 += pdata['p0']
                g_total += pdata['total']
                
                formatted_lines.append({
                    'id': f"partner_{pid}",
                    'name': pdata['name'],
                    'partner_id': pid,
                    'not_due': pdata['not_due'],
                    'p4': pdata['p4'],
                    'p3': pdata['p3'],
                    'p2': pdata['p2'],
                    'p1': pdata['p1'],
                    'p0': pdata['p0'],
                    'total': pdata['total'],
                    'level': 2,
                    'type': 'group',
                    'action_buttons': [
                        {'label': 'Partner', 'class': 'btn-outline-secondary btn-sm badge-pill me-1', 'action': 'open_partner'},
                        {'label': 'Statement', 'class': 'btn-outline-secondary btn-sm badge-pill', 'action': 'open_statement'},
                    ] if pid else []
                })
                formatted_lines.extend(pdata['lines'])
                
            # Add Total row at top
            if formatted_lines:
                formatted_lines.insert(0, {
                    'id': 'total',
                    'name': result['title'],
                    'not_due': g_not_due,
                    'p4': g_p4,
                    'p3': g_p3,
                    'p2': g_p2,
                    'p1': g_p1,
                    'p0': g_p0,
                    'total': g_total,
                    'level': 1,
                    'type': 'total',
                })
                
            result['lines'] = formatted_lines
            
        elif model_name == 'account.print.journal':
            result['title'] = _("Journal Audit")
            result['columns'] = [
                {'label': 'Name', 'field': 'name'},
                {'label': 'Documents', 'field': 'docs_count', 'type': 'integer'},
                {'label': 'To Review', 'field': 'draft_count', 'type': 'integer'},
                {'label': 'Debit', 'field': 'debit', 'type': 'monetary'},
                {'label': 'Credit', 'field': 'credit', 'type': 'monetary'},
                {'label': 'Balance', 'field': 'balance', 'type': 'monetary'},
            ]
            
            wizard = self.env[model_name].browse(wizard_id)
            if not wizard.exists():
                clean_data = {k: v for k, v in form_data.items() if k in self.env[model_name]._fields}
                wizard = self.env[model_name].new(clean_data)
                
            journal_ids = wizard.journal_ids.ids if hasattr(wizard, 'journal_ids') and wizard.journal_ids else form_data.get('journal_ids', [])
            target_move = wizard.target_move if hasattr(wizard, 'target_move') else form_data.get('target_move', 'all')
            date_from = wizard.date_from if hasattr(wizard, 'date_from') else form_data.get('date_from')
            date_to = wizard.date_to if hasattr(wizard, 'date_to') else form_data.get('date_to')
            
            cr = self.env.cr
            # 1. Journals Summary
            j_query = """
                SELECT 
                    j.id as journal_id,
                    j.name as journal_name,
                    j.code as journal_code,
                    COUNT(DISTINCT m.id) as docs_count,
                    COUNT(DISTINCT CASE WHEN m.state = 'draft' THEN m.id END) as draft_count,
                    SUM(l.debit) as debit,
                    SUM(l.credit) as credit,
                    SUM(l.balance) as balance
                FROM account_move_line l
                JOIN account_move m ON l.move_id = m.id
                JOIN account_journal j ON l.journal_id = j.id
                WHERE l.display_type NOT IN ('line_section', 'line_note')
            """
            j_params = []
            if journal_ids:
                j_query += " AND l.journal_id IN %s"
                j_params.append(tuple(journal_ids))
            if target_move == 'posted':
                j_query += " AND m.state = 'posted'"
            if date_from:
                j_query += " AND l.date >= %s"
                j_params.append(date_from)
            if date_to:
                j_query += " AND l.date <= %s"
                j_params.append(date_to)
                
            j_query += " GROUP BY j.id, j.name, j.code ORDER BY j.name"
            cr.execute(j_query, tuple(j_params))
            journals_data = cr.dictfetchall()
            
            # 2. Accounts Summary (Child of Journal)
            a_query = """
                SELECT 
                    j.id as journal_id,
                    a.id as account_id,
                    SUM(l.debit) as debit,
                    SUM(l.credit) as credit,
                    SUM(l.balance) as balance
                FROM account_move_line l
                JOIN account_move m ON l.move_id = m.id
                JOIN account_journal j ON l.journal_id = j.id
                JOIN account_account a ON l.account_id = a.id
                WHERE l.display_type NOT IN ('line_section', 'line_note')
            """
            a_params = []
            if journal_ids:
                a_query += " AND l.journal_id IN %s"
                a_params.append(tuple(journal_ids))
            if target_move == 'posted':
                a_query += " AND m.state = 'posted'"
            if date_from:
                a_query += " AND l.date >= %s"
                a_params.append(date_from)
            if date_to:
                a_query += " AND l.date <= %s"
                a_params.append(date_to)
                
            a_query += " GROUP BY j.id, a.id"
            cr.execute(a_query, tuple(a_params))
            accounts_data = cr.dictfetchall()
            
            account_ids = [a['account_id'] for a in accounts_data]
            accounts = self.env['account.account'].browse(account_ids)
            account_map = {acc.id: {'code': acc.code, 'name': acc.name} for acc in accounts}
            
            # 3. Taxes Summary (Child of Journal)
            t_query = """
                SELECT 
                    l.journal_id as journal_id,
                    t.id as tax_id,
                    t.name as tax_name,
                    SUM(l.tax_base_amount) as base_amount,
                    SUM(l.balance) as tax_amount
                FROM account_move_line l
                JOIN account_move m ON l.move_id = m.id
                JOIN account_tax t ON l.tax_line_id = t.id
                WHERE l.tax_line_id IS NOT NULL
            """
            t_params = []
            if journal_ids:
                t_query += " AND l.journal_id IN %s"
                t_params.append(tuple(journal_ids))
            if target_move == 'posted':
                t_query += " AND m.state = 'posted'"
            if date_from:
                t_query += " AND l.date >= %s"
                t_params.append(date_from)
            if date_to:
                t_query += " AND l.date <= %s"
                t_params.append(date_to)
                
            t_query += " GROUP BY l.journal_id, t.id, t.name ORDER BY t.name"
            cr.execute(t_query, tuple(t_params))
            taxes_data = cr.dictfetchall()
            journal_ids_fetched = [j['journal_id'] for j in journals_data]
            journals = self.env['account.journal'].browse(journal_ids_fetched)
            journal_map = {j.id: {'name': j.name, 'code': j.code} for j in journals}
            
            formatted_lines = []
            
            for j in journals_data:
                j_info = journal_map[j['journal_id']]
                # Add Journal Group Row
                formatted_lines.append({
                    'id': f"journal_{j['journal_id']}",
                    'name': f"{j_info['name']} {j_info['code']}",
                    'docs_count': j['docs_count'],
                    'draft_count': j['draft_count'],
                    'debit': j['debit'] or 0.0,
                    'credit': j['credit'] or 0.0,
                    'balance': '',  # Blank for journal level
                    'level': 1,
                    'type': 'group',
                    'journal_id': j['journal_id'],
                    'action_buttons': [
                        {'label': 'Audit', 'class': 'btn-outline-secondary btn-sm badge-pill me-1', 'action': 'open_journal_items'},
                    ]
                })
                
                # Accounts inside this Journal
                j_accounts = [a for a in accounts_data if a['journal_id'] == j['journal_id']]
                
                # Sort j_accounts by account code since we didn't sort in SQL
                j_accounts = sorted(j_accounts, key=lambda a: account_map[a['account_id']]['code'] or '')
                
                for a in j_accounts:
                    acc_info = account_map[a['account_id']]
                    formatted_lines.append({
                        'id': f"account_{j['journal_id']}_{a['account_id']}",
                        'name': f"{acc_info['code'] or ''} {acc_info['name'] or ''}".strip(),
                        'docs_count': '',
                        'draft_count': '',
                        'debit': a['debit'] or 0.0,
                        'credit': a['credit'] or 0.0,
                        'balance': a['balance'] or 0.0,
                        'level': 2,
                        'type': 'account',
                        'account_id': a['account_id'],
                        'journal_id': j['journal_id'],
                    })
                    
                # Taxes inside this Journal
                j_taxes = [t for t in taxes_data if t['journal_id'] == j['journal_id']]
                if j_taxes:
                    formatted_lines.append({
                        'id': f"tax_header_title_{j['journal_id']}",
                        'name': 'Taxes Applied',
                        'docs_count': '',
                        'draft_count': '',
                        'debit': '',
                        'credit': '',
                        'balance': '',
                        'level': 2,
                        'type': 'group',
                        'journal_id': j['journal_id'],
                        'action_buttons': [{'label': 'Audit', 'class': 'btn-outline-secondary btn-sm badge-pill', 'action': 'open_journal_items'}]
                    })
                    
                    formatted_lines.append({
                        'id': f"tax_header_cols_{j['journal_id']}",
                        'name': 'Name',
                        'docs_count': '',
                        'draft_count': '',
                        'debit': 'Base Amount',  # Overloaded into debit
                        'credit': 'Tax Amount',  # Overloaded into credit
                        'balance': '',
                        'level': 3,
                        'type': 'tax_cols'
                    })
                    
                    for t in j_taxes:
                        formatted_lines.append({
                            'id': f"tax_{j['journal_id']}_{t['tax_id']}",
                            'name': t['tax_name'],
                            'docs_count': '',
                            'draft_count': '',
                            'debit': t['base_amount'] or 0.0,
                            'credit': abs(t['tax_amount']) or 0.0,
                            'balance': '',
                            'level': 3,
                            'type': 'tax'
                        })
            
            result['lines'] = formatted_lines
        else:
            result['title'] = _("Report")
            result['columns'] = [{'label': 'Name', 'field': 'name'}]
            
        return result

