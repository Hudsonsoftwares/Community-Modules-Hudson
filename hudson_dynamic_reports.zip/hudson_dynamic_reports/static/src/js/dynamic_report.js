/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class DynamicReport extends Component {
    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({
            title: "Loading...",
            columns: [],
            lines: [],
            expandedLines: {},
            currencyId: null,
            alert_message: null,
            filterSummary: {
                date: 'Fiscal Year',
                target_move: 'Posted Entries',
                account_type: 'receivable',
                date_basis: 'date_maturity',
                period_length: 30,
                show_draft: false,
                show_currency: false,
                show_account: false,
                hide_lines_at_0: true,
                partners: [],
                tags: []
            },
            customDateFrom: '',
            customDateTo: '',
            partnerSearch: '',
            tagSearch: '',
            analyticSearch: '',
            analyticPlanSearch: '',
            partnerResults: [],
            tagResults: [],
            analyticResults: [],
            analyticPlanResults: [],
            unfoldAll: false,
            model_name: null
        });

        onWillStart(async () => {
            await this.fetchData();
        });
    }

    async fetchData() {
        let params = this.props.action.params || {};
        
        // Use action ID to uniquely identify the report parameters to survive breadcrumb navigation and F5 refreshes
        const storageKey = 'hudson_report_params_' + (this.props.action.id || 'default');
        
        if (params.model_name) {
            sessionStorage.setItem(storageKey, JSON.stringify(params));
        } else {
            const saved = sessionStorage.getItem(storageKey);
            if (saved) {
                params = JSON.parse(saved);
                // Also update the action so it has it for other functions
                this.props.action.params = params;
            }
        }
        
        const wizard_id = params.wizard_id || null;
        const data = params.data || {};
        const model_name = params.model_name || null;
        
        this.state.model_name = model_name;
        
        if (!data.form) data.form = {};
        if (!data.form.date_from && !data.form.date_to && model_name !== 'account.aged.report') {
            const now = new Date();
            const firstDay = new Date(now.getFullYear(), 0, 1);
            const lastDay = new Date(now.getFullYear(), 11, 31);
            data.form.date_from = firstDay.toISOString().split('T')[0];
            data.form.date_to = lastDay.toISOString().split('T')[0];
            if (data.form.used_context) {
                data.form.used_context.date_from = data.form.date_from;
                data.form.used_context.date_to = data.form.date_to;
            }
        }

        // If it's an aged report, try to read the wizard's actual values to populate filterSummary
        if (model_name === 'account.aged.report' && wizard_id) {
            try {
                const wizData = await this.orm.read(model_name, [wizard_id], ['as_of_date', 'account_type', 'date_basis', 'period_length', 'show_draft', 'show_currency', 'show_account', 'hide_lines_at_0', 'partner_ids', 'partner_category_ids']);
                if (wizData && wizData.length > 0) {
                    const wiz = wizData[0];
                    this.state.filterSummary.date = wiz.as_of_date;
                    this.state.filterSummary.account_type = wiz.account_type;
                    this.state.filterSummary.date_basis = wiz.date_basis;
                    this.state.filterSummary.period_length = wiz.period_length;
                    this.state.filterSummary.show_draft = wiz.show_draft;
                    this.state.filterSummary.show_currency = wiz.show_currency;
                    this.state.filterSummary.show_account = wiz.show_account;
                    this.state.filterSummary.hide_lines_at_0 = wiz.hide_lines_at_0;
                    
                    if (wiz.partner_ids && wiz.partner_ids.length > 0) {
                        const partners = await this.orm.read('res.partner', wiz.partner_ids, ['id', 'name']);
                        this.state.filterSummary.partners = partners;
                    }
                    if (wiz.partner_category_ids && wiz.partner_category_ids.length > 0) {
                        const tags = await this.orm.read('res.partner.category', wiz.partner_category_ids, ['id', 'name']);
                        this.state.filterSummary.tags = tags;
                    }
                }
            } catch (e) {
                console.warn("Could not read wizard data", e);
            }
        }

        const result = await this.orm.call("hudson.dynamic.report", "get_report_data", [
            model_name,
            wizard_id,
            data
        ]);

        this.state.title = result.title;
        this.state.columns = result.columns;
        this.state.lines = result.lines;
        this.state.currencyId = result.currency_id;
        this.state.alert_message = result.alert_message || null;
        
        // Expand all lines by default
        for (const line of result.lines) {
            this.state.expandedLines[line.id] = true;
        }
    }

    async onDateFilter(type) {
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        const now = new Date();
        
        if (type === 'today') {
            const today = now.toISOString().split('T')[0];
            form_data.date_from = today;
            form_data.date_to = today;
            this.state.filterSummary.date = 'Today';
            this.state.filterSummary.date_type = 'today';
        } else if (type === 'this_month') {
            const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
            const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            form_data.date_from = firstDay.toISOString().split('T')[0];
            form_data.date_to = lastDay.toISOString().split('T')[0];
            this.state.filterSummary.date = 'This Month';
            this.state.filterSummary.date_type = 'this_month';
        } else if (type === 'this_quarter') {
            const quarter = Math.floor(now.getMonth() / 3);
            const firstDay = new Date(now.getFullYear(), quarter * 3, 1);
            const lastDay = new Date(now.getFullYear(), quarter * 3 + 3, 0);
            form_data.date_from = firstDay.toISOString().split('T')[0];
            form_data.date_to = lastDay.toISOString().split('T')[0];
            this.state.filterSummary.date = 'This Quarter';
            this.state.filterSummary.date_type = 'this_quarter';
        } else if (type === 'this_year') {
            // Assuming Jan-Dec fiscal year for simplicity
            const firstDay = new Date(now.getFullYear(), 0, 1);
            const lastDay = new Date(now.getFullYear(), 11, 31);
            form_data.date_from = firstDay.toISOString().split('T')[0];
            form_data.date_to = lastDay.toISOString().split('T')[0];
            this.state.filterSummary.date = 'Fiscal Year';
            this.state.filterSummary.date_type = 'this_year';
        }
        
        if (form_data.used_context) {
            form_data.used_context.date_from = form_data.date_from;
            form_data.used_context.date_to = form_data.date_to;
        }
        
        // Write to wizard to ensure backend sync
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            try {
                await this.orm.write(model_name, [wizard_id], {
                    date_from: form_data.date_from,
                    date_to: form_data.date_to,
                });
            } catch (e) {
                // Ignore field errors if model doesn't support date_from
                console.warn("Could not write date fields to wizard", e);
            }
        }
        
        await this.fetchData();
    }

    async applyCustomDates() {
        if (!this.state.customDateFrom || !this.state.customDateTo) return;
        
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        
        form_data.date_from = this.state.customDateFrom;
        form_data.date_to = this.state.customDateTo;
        this.state.filterSummary.date = `${this.state.customDateFrom} to ${this.state.customDateTo}`;
        
        if (form_data.used_context) {
            form_data.used_context.date_from = form_data.date_from;
            form_data.used_context.date_to = form_data.date_to;
        }
        
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            try {
                await this.orm.write(model_name, [wizard_id], {
                    date_from: form_data.date_from,
                    date_to: form_data.date_to,
                });
            } catch (e) {
                console.warn("Could not write date fields to wizard", e);
            }
        }
        
        await this.fetchData();
    }

    async onTargetMove(type) {
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        
        form_data.target_move = type;
        this.state.filterSummary.target_move = type === 'posted' ? 'Posted Entries' : 'All Entries';
        
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            await this.orm.write(model_name, [wizard_id], {
                target_move: form_data.target_move,
            });
        }
        
        await this.fetchData();
    }

    async onComparisonFilter(type) {
        this.state.filterSummary.comparison = type;
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        form_data.comparison = type;
        form_data.previous_periods = this.state.filterSummary.previous_periods || 1;
        if (type === 'specific_date') {
            form_data.date_to_cmp = this.state.filterSummary.date_to_cmp;
        }
        
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            try {
                // If model supports these fields
                await this.orm.write(model_name, [wizard_id], {
                    comparison: form_data.comparison,
                    previous_periods: form_data.previous_periods,
                    date_to_cmp: form_data.date_to_cmp || false
                });
            } catch (e) { }
        }
        await this.fetchData();
    }

    async onRounding(type) {
        this.state.filterSummary.rounding = type;
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        form_data.rounding = type;
        await this.fetchData();
    }

    closeBanner() {
        this.state.bannerClosed = true;
    }

    async onAgedDateFilter(type) {
        let newDate = '';
        const today = new Date();
        
        if (type === 'today') {
            newDate = today.toISOString().split('T')[0];
        } else if (type === 'end_last_month') {
            const date = new Date(today.getFullYear(), today.getMonth(), 0);
            newDate = date.toISOString().split('T')[0];
        } else if (type === 'end_last_quarter') {
            const q = Math.floor(today.getMonth() / 3);
            const date = new Date(today.getFullYear(), q * 3, 0);
            newDate = date.toISOString().split('T')[0];
        } else if (type === 'end_last_year') {
            const date = new Date(today.getFullYear(), 0, 0);
            newDate = date.toISOString().split('T')[0];
        } else if (type === 'custom') {
            newDate = this.state.customDateFrom;
            if (!newDate) return;
        }

        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name === 'account.aged.report') {
            await this.orm.write(model_name, [wizard_id], { as_of_date: newDate });
        }
        await this.fetchData();
    }

    async onAgedAccountFilter(type) {
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name === 'account.aged.report') {
            await this.orm.write(model_name, [wizard_id], { account_type: type });
        }
        await this.fetchData();
    }

    async onAgedBasisFilter(type) {
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name === 'account.aged.report') {
            await this.orm.write(model_name, [wizard_id], { date_basis: type });
        }
        await this.fetchData();
    }

    async onAgedPeriodFilter(days) {
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name === 'account.aged.report') {
            await this.orm.write(model_name, [wizard_id], { period_length: parseInt(days) });
        }
        await this.fetchData();
    }

    async onAgedToggleOption(option) {
        this.state.filterSummary[option] = !this.state.filterSummary[option];
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name === 'account.aged.report') {
            const vals = {};
            vals[option] = this.state.filterSummary[option];
            await this.orm.write(model_name, [wizard_id], vals);
        }
        await this.fetchData();
    }

    onUnfoldAllToggle() {
        this.state.unfoldAll = !this.state.unfoldAll;
        // Apply to all currently visible lines
        if (this.state.unfoldAll) {
            this.state.lines.forEach(l => {
                if (l.type === 'group' || l.level === 1 || l.level === 2) {
                    this.state.expandedLines[l.id] = true;
                }
            });
        } else {
            this.state.expandedLines = {};
        }
    }

    async onPartnerSearch(ev) {
        const val = ev.target.value;
        if (!val) {
            await this.loadDefaultPartners();
            return;
        }
        if (val.length < 2) {
            this.state.partnerResults = [];
            return;
        }
        // Basic debounce
        if (this.partnerTimeout) clearTimeout(this.partnerTimeout);
        this.partnerTimeout = setTimeout(async () => {
            const results = await this.orm.searchRead('res.partner', [['name', 'ilike', val]], ['id', 'name'], { limit: 10 });
            this.state.partnerResults = results;
        }, 300);
    }

    async loadDefaultPartners() {
        if (!this.state.partnerResults || this.state.partnerResults.length === 0) {
            const results = await this.orm.searchRead('res.partner', [], ['id', 'name'], { limit: 20, order: 'name asc' });
            this.state.partnerResults = results;
        }
    }

    async onTagSearch(ev) {
        const val = ev.target.value;
        if (!val || val.length < 2) {
            this.state.tagResults = [];
            return;
        }
        if (this.tagTimeout) clearTimeout(this.tagTimeout);
        this.tagTimeout = setTimeout(async () => {
            const results = await this.orm.searchRead('res.partner.category', [['name', 'ilike', val]], ['id', 'name'], { limit: 10 });
            this.state.tagResults = results;
        }, 300);
    }

    selectPartner(p) {
        if (!this.state.filterSummary.partners.find(x => x.id === p.id)) {
            this.state.filterSummary.partners.push(p);
        }
        this.state.partnerSearch = '';
        this.state.partnerResults = [];
    }

    selectTag(t) {
        if (!this.state.filterSummary.tags.find(x => x.id === t.id)) {
            this.state.filterSummary.tags.push(t);
        }
        this.state.tagSearch = '';
        this.state.tagResults = [];
    }

    removePartner(pid) {
        this.state.filterSummary.partners = this.state.filterSummary.partners.filter(p => p.id !== pid);
    }

    removeTag(tid) {
        this.state.filterSummary.tags = this.state.filterSummary.tags.filter(t => t.id !== tid);
    }

    async applyPartnerFilters() {
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            try {
                await this.orm.write(model_name, [wizard_id], { 
                    partner_ids: [[6, 0, this.state.filterSummary.partners.map(p => p.id)]],
                    partner_category_ids: [[6, 0, this.state.filterSummary.tags.map(t => t.id)]]
                });
            } catch (e) { }
        }
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        form_data.partner_ids = this.state.filterSummary.partners.map(p => p.id);
        form_data.partner_category_ids = this.state.filterSummary.tags.map(t => t.id);
        await this.fetchData();
    }

    async onAnalyticSearch(ev) {
        const val = ev.target.value;
        if (!val) {
            await this.loadDefaultAnalytics();
            return;
        }
        if (val.length < 2) {
            this.state.analyticResults = [];
            return;
        }
        if (this.analyticTimeout) clearTimeout(this.analyticTimeout);
        this.analyticTimeout = setTimeout(async () => {
            const results = await this.orm.searchRead('account.analytic.account', [['name', 'ilike', val]], ['id', 'name'], { limit: 10 });
            this.state.analyticResults = results;
        }, 300);
    }

    async loadDefaultAnalytics() {
        if (!this.state.analyticResults || this.state.analyticResults.length === 0) {
            const results = await this.orm.searchRead('account.analytic.account', [], ['id', 'name'], { limit: 20, order: 'name asc' });
            this.state.analyticResults = results;
        }
    }

    selectAnalyticAccount(a) {
        if (!this.state.filterSummary.analytic_accounts) this.state.filterSummary.analytic_accounts = [];
        if (!this.state.filterSummary.analytic_accounts.find(x => x.id === a.id)) {
            this.state.filterSummary.analytic_accounts.push(a);
        }
        this.state.analyticSearch = '';
        this.state.analyticResults = [];
    }

    removeAnalyticAccount(aid) {
        if (this.state.filterSummary.analytic_accounts) {
            this.state.filterSummary.analytic_accounts = this.state.filterSummary.analytic_accounts.filter(a => a.id !== aid);
        }
    }

    async applyAnalyticFilters() {
        const wizard_id = this.props.action.params.wizard_id;
        const model_name = this.props.action.params.model_name;
        if (wizard_id && model_name) {
            try {
                await this.orm.write(model_name, [wizard_id], { 
                    analytic_account_ids: [[6, 0, (this.state.filterSummary.analytic_accounts || []).map(a => a.id)]]
                });
            } catch (e) { }
        }
        const data = this.props.action.params.data || {};
        const form_data = data.form || data;
        form_data.analytic_account_ids = (this.state.filterSummary.analytic_accounts || []).map(a => a.id);
        form_data.analytic_plan_ids = (this.state.filterSummary.analytic_plans || []).map(p => p.id);
        await this.fetchData();
    }

    async onAnalyticPlanSearch(ev) {
        const val = ev.target.value;
        if (!val) {
            await this.loadDefaultAnalyticPlans();
            return;
        }
        if (val.length < 2) {
            this.state.analyticPlanResults = [];
            return;
        }
        if (this.analyticPlanTimeout) clearTimeout(this.analyticPlanTimeout);
        this.analyticPlanTimeout = setTimeout(async () => {
            const results = await this.orm.searchRead('account.analytic.plan', [['name', 'ilike', val]], ['id', 'name'], { limit: 10 });
            this.state.analyticPlanResults = results;
        }, 300);
    }

    async loadDefaultAnalyticPlans() {
        if (!this.state.analyticPlanResults || this.state.analyticPlanResults.length === 0) {
            const results = await this.orm.searchRead('account.analytic.plan', [], ['id', 'name'], { limit: 20, order: 'name asc' });
            this.state.analyticPlanResults = results;
        }
    }

    selectAnalyticPlan(p) {
        if (!this.state.filterSummary.analytic_plans) this.state.filterSummary.analytic_plans = [];
        if (!this.state.filterSummary.analytic_plans.find(x => x.id === p.id)) {
            this.state.filterSummary.analytic_plans.push(p);
        }
        this.state.analyticPlanSearch = '';
        this.state.analyticPlanResults = [];
    }

    removeAnalyticPlan(pid) {
        if (this.state.filterSummary.analytic_plans) {
            this.state.filterSummary.analytic_plans = this.state.filterSummary.analytic_plans.filter(p => p.id !== pid);
        }
    }

    toggleExpand(lineId) {
        this.state.expandedLines[lineId] = !this.state.expandedLines[lineId];
    }

    isVisible(line) {
        if (line.level === 1) return true;
        
        const lines = this.state.lines;
        const index = lines.indexOf(line);
        for (let i = index - 1; i >= 0; i--) {
            if (lines[i].level < line.level) {
                if (!this.state.expandedLines[lines[i].id]) {
                    return false;
                }
                if (!this.isVisible(lines[i])) {
                    return false;
                }
                break;
            }
        }
        return true;
    }

    formatMonetary(value) {
        if (value === undefined || value === null) return "";
        let num = Number(value);
        const rounding = this.state.filterSummary.rounding !== undefined ? this.state.filterSummary.rounding : '.';
        if (rounding === 'K') {
            num = num / 1000;
        } else if (rounding === 'L') {
            num = num / 100000;
        } else if (rounding === 'M') {
            num = num / 1000000;
        }
        const decimals = (rounding === '.') ? 2 : 0;
        return num.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    }

    hasChildren(line) {
        const lines = this.state.lines;
        const index = lines.indexOf(line);
        if (index < lines.length - 1) {
            return lines[index + 1].level > line.level;
        }
        return false;
    }
    
    async onLineClicked(line) {
        const params = this.props.action.params || {};
        const model_name = params.model_name;
        const data = params.data || {};
        const form_data = data.form || data;
        
        if (line.type === 'account' && model_name === 'accounting.report') {
            const date_from = form_data.date_from || form_data.date_from_cmp;
            const date_to = form_data.date_to || form_data.date_to_cmp;
            
            // Extract account code
            const nameParts = line.name.split(' ');
            const code = nameParts[0];
            
            const action = {
                type: 'ir.actions.act_window',
                name: 'Journal Items',
                res_model: 'account.move.line',
                view_mode: 'list,form',
                views: [[false, 'list'], [false, 'form']],
                domain: [['account_id.code', '=', code]],
            };
            
            if (date_from) action.domain.push(['date', '>=', date_from]);
            if (date_to) action.domain.push(['date', '<=', date_to]);
            
            await this.action.doAction(action);
        } else if (line.type === 'account' && model_name === 'account.report.partner.ledger') {
            if (line.move_line_id) {
                const action = {
                    type: 'ir.actions.act_window',
                    name: 'Journal Item',
                    res_model: 'account.move.line',
                    res_id: line.move_line_id,
                    view_mode: 'form',
                    views: [[false, 'form']],
                };
                await this.action.doAction(action);
            }
        }
    }

    async onAuditTax(line) {
        if (!line.tax_id) return;
        
        const params = this.props.action.params || {};
        const data = params.data || {};
        const form_data = data.form || data;
        
        const date_from = form_data.date_from;
        const date_to = form_data.date_to;
        
        const action = {
            type: 'ir.actions.act_window',
            name: 'Journal Items for Tax Audit',
            res_model: 'account.move.line',
            view_mode: 'list,form',
            views: [[false, 'list'], [false, 'form']],
            domain: ['|', ['tax_line_id', '=', line.tax_id], ['tax_ids', 'in', [line.tax_id]]],
            context: {
                'search_default_group_by_account': 1,
            }
        };
        
        if (date_from) action.domain.push(['date', '>=', date_from]);
        if (date_to) action.domain.push(['date', '<=', date_to]);
        
        await this.action.doAction(action);
    }

    async onActionClicked(line, actionName) {
        const params = this.props.action.params || {};
        const data = params.data || {};
        const form_data = data.form || data;
        
        if (actionName === 'open_partner' && line.partner_id) {
            await this.action.doAction({
                type: 'ir.actions.act_window',
                name: 'Partner',
                res_model: 'res.partner',
                res_id: line.partner_id,
                view_mode: 'form',
                views: [[false, 'form']],
            });
        } else if (actionName === 'open_journal_items') {
            const date_from = form_data.date_from;
            const date_to = form_data.date_to;
            
            const domain = [];
            if (line.partner_id) domain.push(['partner_id', '=', line.partner_id]);
            if (line.account_id) domain.push(['account_id', '=', line.account_id]);
            if (line.journal_id) domain.push(['journal_id', '=', line.journal_id]);
            
            const action = {
                type: 'ir.actions.act_window',
                name: 'Journal Items',
                res_model: 'account.move.line',
                view_mode: 'list,form',
                views: [[false, 'list'], [false, 'form']],
                domain: domain,
            };
            
            if (date_from) action.domain.push(['date', '>=', date_from]);
            if (date_to) action.domain.push(['date', '<=', date_to]);
            
            await this.action.doAction(action);
        } else if (actionName === 'open_general_ledger' && line.account_id) {
            const date_from = form_data.date_from;
            const date_to = form_data.date_to;
            
            const action = {
                type: 'ir.actions.act_window',
                name: 'General Ledger',
                res_model: 'account.move.line',
                view_mode: 'list,form',
                views: [[false, 'list'], [false, 'form']],
                domain: [['account_id', '=', line.account_id]],
            };
            
            if (date_from) action.domain.push(['date', '>=', date_from]);
            if (date_to) action.domain.push(['date', '<=', date_to]);
            
            await this.action.doAction(action);
        } else if (actionName === 'open_journal_entry' && line.move_id) {
            await this.action.doAction({
                type: 'ir.actions.act_window',
                name: 'Journal Entry',
                res_model: 'account.move',
                res_id: line.move_id,
                view_mode: 'form',
                views: [[false, 'form']],
            });
        } else if (actionName === 'open_statement' && line.partner_id) {
            const action = await this.orm.call("hudson.dynamic.report", "action_open_statement", [
                line.partner_id
            ]);
            await this.action.doAction(action);
        }
    }

    async exportPDF() {
        const params = this.props.action.params || {};
        const model_name = params.model_name;
        const wizard_id = params.wizard_id;
        const data = params.data || {};
        
        if (model_name && wizard_id) {
            const context = {
                active_model: data.model || this.props.action.context?.active_model || model_name,
                active_ids: data.ids || this.props.action.context?.active_ids || [wizard_id],
                active_id: (data.ids && data.ids[0]) || this.props.action.context?.active_id || wizard_id,
            };
            const action = await this.orm.call(model_name, "check_report", [[wizard_id]], { context });
            if (action) {
                if (!action.context) {
                    action.context = {};
                }
                Object.assign(action.context, context);
                await this.action.doAction(action);
            }
        }
    }

    exportXLSX() {
        // Export all lines regardless of expansion state
        const lines = this.state.lines;
        
        // Prepare data for backend
        const reportData = {
            title: this.state.title,
            columns: this.state.columns,
            lines: lines,
            date_str: this.state.filterSummary.date === 'Fiscal Year' ? new Date().toLocaleDateString() : this.state.filterSummary.date
        };
        
        // Create a hidden form to submit via POST for file download
        const form = document.createElement("form");
        form.method = "POST";
        form.action = "/hudson_dynamic_reports/export_xlsx";
        
        const dataInput = document.createElement("input");
        dataInput.type = "hidden";
        dataInput.name = "data";
        dataInput.value = JSON.stringify(reportData);
        form.appendChild(dataInput);
        
        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    }

    exportJSON() {
        const data = {
            title: this.state.title,
            columns: this.state.columns,
            lines: this.state.lines
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `${this.state.title.replace(/\s+/g, '_')}.json`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
}

DynamicReport.template = "hudson_dynamic_reports.DynamicReport";

registry.category("actions").add("hudson_dynamic_reports.dynamic_report", DynamicReport);
